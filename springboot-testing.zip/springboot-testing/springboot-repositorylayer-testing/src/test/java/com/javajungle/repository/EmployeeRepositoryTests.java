package com.javajungle.repository;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.javajungle.entity.Employee;

@DataJpaTest
public class EmployeeRepositoryTests {

	@Autowired
	private EmployeeRepository repository;
	
	private Employee employee;
	
	@BeforeEach
	public void setUp()
	{
		employee = Employee.builder().firstName("ts").lastName("javajungle").email("rams.11mca@gmail.com").build();
	}
	
	@Test
	@DisplayName("junit test case for saving the employee operation")
	@Disabled
	public void givenEmployeeObject_whenSave_thenReturnSavedEmployeeObject()
	{
		//given - precondition or setup
		Employee employee = Employee.builder().firstName("ts").lastName("javajungle").email("rams.11mca@gmail.com").build();
	
	    //when - action or the behavior that we are going to test
		Employee savedEmployee = repository.save(employee);
		System.out.println(savedEmployee);
	    //then - verify the output
		assertThat(savedEmployee).isNotNull();
		assertThat(savedEmployee.getEmpid()).isGreaterThan(0);
	}
	
	@Test
	@DisplayName("junit test case for getting all employees operation")
	@Disabled
	public void givenEmployeeList_whenFindAll_thenEmployeeList()
	{
		//given - precondition or setup
		Employee employee1 = Employee.builder().firstName("rk").lastName("javajungle").email("rams.11mca@gmail.com").build();
		Employee employee2 = Employee.builder().firstName("chenna").lastName("javajungle").email("chennamailme@gmail.com").build();
		
		repository.save(employee1);
		repository.save(employee2);
		//when - action or the behaviour we are going to test
		
		List<Employee> employeesList = repository.findAll();
		
		//then - verify the output
		assertThat(employeesList).isNotNull();
		assertThat(employeesList.size()).isEqualTo(2);
	}
	
	
	@Test
	@DisplayName("junit test case for getting the employee by passing id operation")
	@Disabled
	public void givenEmployeeObject_whenFindById_thenReturnEmployeeObject()
	{
		//given
		Employee employee = Employee.builder().firstName("rk").lastName("javajungle").email("rams.11mca@gmail.com").build();
		Employee savedEmployee = repository.save(employee);
		
		//when
		Employee emp = repository.findById(savedEmployee.getEmpid()).get();
		
		//then
		
		assertThat(emp).isNotNull();
		assertThat(emp.getEmpid()).isGreaterThan(0);
	}
	
	
	@Test
	@DisplayName("junit test case for getting the employee by passing an email")
	@Disabled
	public void givenEmployeeEmail_whenfindByEmail_thenReturnEmployeeObject()
	{
		//given
		Employee employee = Employee.builder().firstName("rk").lastName("javajungle").email("rams.11mca@gmail.com").build();
		
		repository.save(employee);
		
		//when
		Employee savedEmployee = repository.findByEmail(employee.getEmail()).get();
	
		//then
		assertThat(savedEmployee).isNotNull();
		assertThat(savedEmployee.getEmail()).isEqualTo("rams.11mca@gmail.com");
		
	}
	
	
	@Test
	@DisplayName("junit test for update the employee operation")
	@Disabled
	public void givenEmployee_whenSave_thenUpdatedEmployeeObject()
	{
		//given - precondition or setup
		
		Employee employee = Employee.builder().firstName("rk").lastName("javajungle").email("rams.11mca@gmail.com").build();
		
		
		//when-action or the behaviour we are going to test
		repository.save(employee);
		
		Employee savedEmployee = repository.findById(employee.getEmpid()).get();
		
		savedEmployee.setFirstName("ram");
		savedEmployee.setLastName("java");
		
	    Employee updatedEmployee = repository.save(savedEmployee);
	    
	    
	    //then - verify the output
	    
	    assertThat(updatedEmployee.getFirstName()).isEqualTo("ram");
	    assertThat(updatedEmployee.getLastName()).isEqualTo("java");
	        
	}
	
	@Test
	@DisplayName("junit test for deleteing the employee operation")
	@Disabled
	public void givenEmployee_whenDelete_thenReturnNothing()
	{
	//given - precondition or setup
		
	Employee employee = Employee.builder().firstName("rk").lastName("javajungle").email("rams.11mca@gmail.com").build();
		
	Employee savedEmployee = repository.save(employee);
	
	//when
	repository.delete(savedEmployee);
	
	Optional<Employee> optional = repository.findById(savedEmployee.getEmpid());
	
	
	//then - verify the output
	
	assertThat(optional).isEmpty();
	
	}
	
	@Test
	@DisplayName("junit test case for jpql with index params")
	@Disabled
	public void givenEmployeeObject_whenfirstNameAndlastName_thenReturnEmployeeObject()
	{
		
		
			//given - precondition or setup
				
			Employee employee = Employee.builder().firstName("rk").lastName("javajungle").email("rams.11mca@gmail.com").build();
			Employee savedEmployee = repository.save(employee);
			
			String firstName="rk";
			String lastName="javajungle";
			//when - the action or the behavior we are going to test
			
			Employee returnObject = repository.findByJPQLIndexParams(firstName,lastName);
			
			
			//then -verify the output
			
			assertThat(returnObject).isNotNull();
	}
	
	
	@Test
	@DisplayName("junit test case for jpql with named params")
	@Disabled
	public void givenEmployeeObject_whenFindByJpqlNamedParams_thenReturnEmployeeObject()
	{
		
		
			//given - precondition or setup
				
			Employee employee = Employee.builder().firstName("rk").lastName("javajungle").email("rams.11mca@gmail.com").build();
			Employee savedEmployee = repository.save(employee);
			
			String firstName="rk";
			String lastName="javajungle";
			//when - the action or the behavior we are going to test
			
			Employee returnObject = repository.findByJPQLNamedParams(firstName,lastName);
			
			
			//then -verify the output
			
			assertThat(returnObject).isNotNull();
	}
	
	
	@Test
	@DisplayName("junit test case for native sql with index params")
	
	public void givenEmployeeObject_whenFindByNativeSQLIndexedParams_thenReturnEmployeeObject()
	{
		
		
			//given - precondition or setup
				
			//Employee employee = Employee.builder().firstName("rk").lastName("javajungle").email("rams.11mca@gmail.com").build();
			Employee savedEmployee = repository.save(employee);
			
			//String firstName="rk";
			//String lastName="javajungle";
			//when - the action or the behavior we are going to test
			
			Employee returnObject = repository.findByNativeSQLIndexParams(savedEmployee.getFirstName(),savedEmployee.getLastName());
			
			
			//then -verify the output
			
			assertThat(returnObject).isNotNull();
	}
	
	
	
}
