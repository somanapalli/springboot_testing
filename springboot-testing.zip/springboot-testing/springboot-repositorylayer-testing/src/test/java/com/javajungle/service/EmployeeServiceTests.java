package com.javajungle.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.BDDMockito;
import org.mockito.BDDMockito.BDDStubber;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.javajungle.entity.Employee;
import com.javajungle.exception.EmployeeEmailExistsException;
import com.javajungle.repository.EmployeeRepository;
import com.javajungle.service.impl.EmployeeServiceImpl;

@ExtendWith(MockitoExtension.class)
public class EmployeeServiceTests {

	@Mock
	private EmployeeRepository repository;
	
	@InjectMocks
	private EmployeeServiceImpl service;
	
	private Employee employee;
	
	@BeforeEach
	@Test
	public void setUp()
	{
		employee= Employee.builder().empid(1).firstName("rk").lastName("javajungle").email("rk@gmail.com").build();
	}
	@Test
	@DisplayName("junit test for saveemployee method")
	@Disabled
	public void givenEmployeeObject_whenSaveEmployee_thenReturnEmployeeObject() 
	{
	   
		given(repository.save(employee)).willReturn(employee);
		
	   //when
		
		Employee savedEmployee = service.saveEmployee(employee);
	   //then
		assertThat(savedEmployee).isNotNull();
		
		
	}
	
	
	@Test
	@DisplayName("junit test for saveemployee method throws exception")
	@Disabled
	public void givenExistsEmail_whenSaveEmployee_thenThrowsException() 
	{
	   //given
		given(repository.findByEmail(employee.getEmail())).willReturn(Optional.of(employee));
		
	   //when
		
		assertThrows(EmployeeEmailExistsException.class,()->{
			service.saveEmployee(employee);
		} );
		
		//then-verify
		verify(repository,never()).save(any(Employee.class));
		
		
	}
	
	
	@Test
	@DisplayName("junit test for getAllEmployees method")
	@Disabled
	public void givenListOfEmployees_whengetAllEmployees_thenReturnsListOfEmployees() 
	{
		Employee employee1= Employee.builder().empid(1).firstName("venkat").lastName("javajungle").email("venkat@gmail.com").build();
	   
		List<Employee> l = new ArrayList();
		l.add(employee);
		l.add(employee1);
		//given
	   given(repository.findAll()).willReturn(l);
	 	
	   //when
		
	   List<Employee> lists = service.getAllEmployees();
		
		//then-verify
	   
	   assertThat(lists).isNotEmpty();
	   
	   assertThat(lists.size()).isEqualTo(2);
		
		
	}
	
	
	
	@Test
	@DisplayName("junit test for getEmployeeById method")
	@Disabled
	public void givenEmployeeId_whengetEmployeeById_thenReturnEmployeeObject() 
	{
		//given
		given(repository.findById(1)).willReturn(Optional.of(employee));
		
		
		//when
		
		Employee savedEmployee = service.getEmployeeById(employee.getEmpid()).get();
		
		//then
		
		assertThat(savedEmployee).isNotNull();
		
	}
	
	@Test
	@DisplayName("junit test case for updating the employee")
	@Disabled
	public void givenEmployee_whenupdateEmployee_thenReturnEmployeeObject()
	{
		
		//given - precondition or setup
		
		given(repository.save(employee)).willReturn(employee);
		
		employee.setFirstName("ram");
		employee.setLastName("java");
		employee.setEmail("ram@gmail.com");
		
		
		//when
		
		Employee updatedEmployee = service.updateEmployee(employee);
		
		//then - verifying the output
		
		assertThat(updatedEmployee).isNotNull();
		assertThat(updatedEmployee.getFirstName()).isEqualTo("ram");
		
	}
	
	@Test
	@DisplayName("junit test case for delete employee by id")
	public void givenEmployeeId_whendeleteById_thenReturnNothing()
	{
		 //given
		BDDMockito.willDoNothing().given(repository).deleteById(employee.getEmpid());
		
		 //when
		
		service.deleteEmployee(employee.getEmpid());
		 //then
		
		verify(repository,times(1)).deleteById(employee.getEmpid());
		
		
	}
	
	
}
