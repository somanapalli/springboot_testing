package com.javajungle.integration;

import static org.hamcrest.CoreMatchers.is;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.BDDMockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.javajungle.entity.Employee;
import com.javajungle.repository.EmployeeRepository;
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureMockMvc
public class EmployeeControllerTests {

	@Autowired
	private MockMvc mockMvc;
	
	@Autowired
	private ObjectMapper objectMapper;
	
	@Autowired
	private EmployeeRepository repository;
	
	@BeforeEach
	void setUp()
	{
		repository.deleteAll();
	}
	
	@Test
	@DisplayName("integration test case for saveemployee of controller class")
	@Disabled
	public void givenEmployee_whensaveEmployee_thenReturnEmployeeObject() throws JsonProcessingException, Exception
	{
		//given-precondition or setup
		
		Employee employee = Employee.builder().firstName("rk")
				.lastName("javajungle")
				.email("rk@gmail.com")
				.build();
		
	    
		//when
		
	    ResultActions response = mockMvc.perform(post("/api/employees")
	    		.contentType(MediaType.APPLICATION_JSON)
	    		.content(objectMapper.writeValueAsString(employee)));
	    
	    
		
		//then
	    response.andExpect(status().isCreated()) 
	    .andDo(print())
	    .andExpect(jsonPath("$.firstName",  is(employee.getFirstName())))
	    .andExpect(jsonPath("$.lastName", is(employee.getLastName())))
	    .andExpect(jsonPath("$.email",is(employee.getEmail())));
	   
	    
	    
	    
	}
	
	@Test
	@DisplayName("integration test for getallemployees")
	@Disabled
	public void givenListOfEmployees_whengetAllEmployees_thenReturnListOfEmployees() throws Exception
	{
		//given 
		List<Employee> list = new ArrayList<Employee>();
		
		list.add(Employee.builder().firstName("rk").lastName("javajungle").email("rk@gmail.com").build());
		list.add(Employee.builder().firstName("vinay").lastName("java").email("vinay@gmail.com").build());
		
		repository.saveAll(list);
		
		
		//when
		
		ResultActions response = mockMvc.perform(get("/api/employees"));
		
		//then
		
		response.andExpect(status().isOk())
		.andDo(print())
		.andExpect(jsonPath("$.size()", is(list.size())));
		
	}
	
	@Test
	@DisplayName("integration test case for getEmployeeById-postiive scenario")
	@Disabled
	public void givenEmployeeId_whengetEmployeeById_thenReturnEmployeeObject() throws Exception
	{
		//given
		
		
		Employee employee = Employee
				.builder()
				.firstName("rk")
				.lastName("javajungle")
				.email("rk@gmail.com")
				.build();
		
		repository.save(employee);
		
		//when
		
		ResultActions response = mockMvc.perform(get("/api/employees/{id}",employee.getEmpid()));
		
		
		//then
		response.andExpect(status().isOk())
		.andDo(print())
		.andExpect(jsonPath("$.firstName", is(employee.getFirstName())))
		.andExpect(jsonPath("$.lastName",is(employee.getLastName())))
		.andExpect(jsonPath("$.email",is(employee.getEmail())));
		
		
	}
	
	
	@Test
	@DisplayName("integration test case for getEmployeeById-negative scenario")
	@Disabled
	public void givenInvalidEmployeeId_whengetEmployeeById_thenReturn404() throws Exception
	{
		//given
		
		Integer employeeId=1;
		Employee employee = Employee
				.builder()
				.firstName("rk")
				.lastName("javajungle")
				.email("rk@gmail.com")
				.build();
		
		repository.save(employee);
		
		//when
		
		ResultActions response = mockMvc.perform(get("/api/employees/{id}",employeeId));
		
		
		//then
		response.andExpect(status().isNotFound())
		.andDo(print());
		
		
		
	}
	
	@Test
	@DisplayName("Integration test case for updateemployee-positive scenario")
	@Disabled
	public void givenuUpdateEmployee_whenupdateEmployee_thenReturnUpdatedEmployeeObject() throws JsonProcessingException, Exception
	{
		
		//given
		
		Employee savedEmployee = Employee
				.builder()
				.firstName("rk")
				.lastName("javajungle")
				.email("rk@gmail.com")
				.build();
		
		repository.save(savedEmployee);
		
		Employee updatedEmployee = Employee
				.builder()
				.firstName("ram")
				.lastName("java-jungle")
				.email("ram@gmail.com")
				.build();
		
		
		
		//when
		
		
		ResultActions response = mockMvc.perform(put("/api/employees/{id}",savedEmployee.getEmpid())
				.contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(updatedEmployee)));
				
		//then
		response.andExpect(status().isOk()).andDo(print())
		.andExpect(jsonPath("$.firstName",is(updatedEmployee.getFirstName())));
		
	}
	
	
	@Test
	@DisplayName("Integration test case for updateemployee-negative scenario")
	@Disabled
	public void givenInvalidEmployeeId_whenupdateEmployee_thenReturn404() throws JsonProcessingException, Exception
	{
		
		//given
		Integer employeeID = 1;
		Employee savedEmployee = Employee
				.builder()
				.firstName("rk")
				.lastName("javajungle")
				.email("rk@gmail.com")
				.build();
		
		repository.save(savedEmployee);
		
		Employee updatedEmployee = Employee
				.builder()
				.firstName("ram")
				.lastName("java-jungle")
				.email("ram@gmail.com")
				.build();
		
		
		
		//when
		
		
		ResultActions response = mockMvc.perform(put("/api/employees/{id}",employeeID)
				.contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(updatedEmployee)));
				
		//then
		response.andExpect(status().isNotFound()).andDo(print());
		
		
	}
	@Test 
	@DisplayName("Integration test case for delete employee")
	public void givenEmployeeId_whendeleteEmployee_thenReturnNothing() throws Exception
	{
		
		Employee savedEmployee = Employee
				.builder()
				.firstName("rk")
				.lastName("javajungle")
				.email("rk@gmail.com")
				.build();
		
		repository.save(savedEmployee);
		//when
		
		ResultActions response = mockMvc.perform(delete("/api/employees/{id}",savedEmployee.getEmpid()));
		//then
		response.andExpect(status().isOk())
		.andDo(print());
	}
	
	
	
}
