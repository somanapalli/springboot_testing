package com.javajungle.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.javajungle.entity.Employee;


public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

	Optional<Employee> findByEmail(String email);
	
	@Query("select e from Employee e where e.firstName=?1 and e.lastName=?2")
	Employee findByJPQLIndexParams(String firstName,String lastName);
	
	
	@Query("select e from Employee e where e.firstName=:p and e.lastName=:q")
	Employee findByJPQLNamedParams(@Param("p") String x,@Param("q")String y);
	
	@Query(value="select * from Employee e where e.first_name=?1 and e.last_name=?2",nativeQuery = true)
	Employee findByNativeSQLIndexParams(String firstName,String lastName);
	
	
	
	
	
	
	
}
