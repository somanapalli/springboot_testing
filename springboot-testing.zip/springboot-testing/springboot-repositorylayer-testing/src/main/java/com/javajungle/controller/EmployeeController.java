package com.javajungle.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.javajungle.entity.Employee;
import com.javajungle.service.EmployeeService;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {

	@Autowired
	private EmployeeService service;

	@PostMapping
	@ResponseStatus(code = HttpStatus.CREATED)
	public Employee saveEmployee(@RequestBody Employee employee) {
		return service.saveEmployee(employee);

	}

	@GetMapping
	@ResponseStatus(code = HttpStatus.OK)
	public List<Employee> getAllEmployees() {
		return service.getAllEmployees();
	}

	@GetMapping("{id}")
	public ResponseEntity<Employee> getEmployeeById(@PathVariable("id") Integer empid) {
		return service.getEmployeeById(empid).map(ResponseEntity::ok)
				.orElseGet(() -> ResponseEntity.notFound().build());
	}

	@PutMapping("{id}")
	public ResponseEntity<Employee> updateEmployee(@PathVariable("id") Integer empid,@RequestBody Employee updatedEmployee)
	{
		return service.getEmployeeById(empid).map(
				savedEmployee -> {
				savedEmployee.setFirstName(updatedEmployee.getFirstName());
				savedEmployee.setLastName(updatedEmployee.getLastName());
				savedEmployee.setEmail(updatedEmployee.getEmail());
				
				Employee updateEmp = service.updateEmployee(savedEmployee);
				
				return new ResponseEntity<>(updateEmp,HttpStatus.OK);
				})
				.orElseGet(()->ResponseEntity.notFound().build());
				
		
	}
	@DeleteMapping("{id}")
	public ResponseEntity<String> deleteEmployee(@PathVariable("id") Integer empid)
	{
		service.deleteEmployee(empid);
		return new ResponseEntity<String>("employee with given employee id delete successfully",HttpStatus.OK);
	}
}
