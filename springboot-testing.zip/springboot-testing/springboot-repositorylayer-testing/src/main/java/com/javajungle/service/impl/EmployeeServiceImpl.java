package com.javajungle.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import com.javajungle.entity.Employee;
import com.javajungle.exception.EmployeeEmailExistsException;
import com.javajungle.repository.EmployeeRepository;
import com.javajungle.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeRepository repository;
	
	public EmployeeServiceImpl(EmployeeRepository repository)
	{
		this.repository=repository;
	}

	@Override
	public Employee saveEmployee(Employee employee){
		
		Optional<Employee> emp = repository.findByEmail(employee.getEmail());
		
		if(emp.isPresent()) {
			
			throw new EmployeeEmailExistsException("employee already existed with the given email:" + employee.getEmail());
		}
		
		return repository.save(employee);
	}

	@Override
	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

	@Override
	public Optional<Employee> getEmployeeById(Integer id) {
		
		return repository.findById(id);
	}

	@Override
	public Employee updateEmployee(Employee employee) {
		
		
		return repository.save(employee);
	}

	@Override
	public void deleteEmployee(Integer id) {
		repository.deleteById(id);
	}

}
